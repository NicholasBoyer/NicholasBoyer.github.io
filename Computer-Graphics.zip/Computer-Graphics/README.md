# Computer-Graphics

# How do I approach designing software?
My approach to software design is to think about the end goal and consider the steps required to achieve that goal. For this project, it meant creating 3D objects, applying textures, and lighting. I first chose a scene I wanted to recreate, and then added elements from that scene to the very best of my ability. This approach could be used for other types of programs, such as accounting programs or video games.
# How do I approach developing programs?
I devloped iteratively by making changes in small incredments and referring back to the source material when I got stuck. I would rebuild the project after making only one change to make sure it still worked. This approach has remained consistent because it is useful and efficient.
# How can computer science help me in reaching my goals?
Creating this project has given me knowledge about how 3D environments work. It has also improved my knowledge of C++ and many libraries such as GLFW. These skillsets will help further my professional and educational careers.
